# market
SSM+Maven 超市进销存管理系统
毕业设计作品，做的有点粗糙，jsp页面没有分类
业务上的处理有的是放在service层处理，有的是使用触发器

