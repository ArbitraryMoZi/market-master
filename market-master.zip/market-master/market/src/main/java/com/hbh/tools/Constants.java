package com.hbh.tools;

public class Constants {
	public final static String Staff_SESSION = "staffSession";
	public final static String Manager_SESSION = "managerSession";
	public final static String SYS_MESSAGE = "message";
	public final static int pageSize = 5;

}
